package com.cognizant.grizzly.service;

import com.cognizant.grizzly.exception.GrizzlyException;
import com.cognizant.grizzly.model.LoginDetails;

public interface ILoginDao {

	int checkLogin(LoginDetails loginDetails) throws GrizzlyException;
	int checkUserName(String Username)throws GrizzlyException;
	int updateStatus(String username)throws GrizzlyException;
	int getStatus(String username)throws GrizzlyException;
	
}
