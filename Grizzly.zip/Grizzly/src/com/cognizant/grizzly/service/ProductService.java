package com.cognizant.grizzly.service;

import java.sql.SQLException;
import java.util.List;

import com.cognizant.grizzly.dao.ProductDao;
import com.cognizant.grizzly.exception.GrizzlyException;
import com.cognizant.grizzly.model.ProductDetails;

public class ProductService implements IProductDao {

	ProductDao productDao=ProductDao.getProductDao();
	@Override
	public int saveProductDetails(ProductDetails productDetails) throws ClassNotFoundException, GrizzlyException, SQLException {
	    
		return productDao.saveProductDetails(productDetails);
	}

	@Override
	public List<ProductDetails> getAllProductDetails() throws GrizzlyException {
		// TODO Auto-generated method stub
		return productDao.getProductDetails();
	}

	@Override
	public int removeProductDetails(int productId) throws ClassNotFoundException, GrizzlyException, SQLException {
		// TODO Auto-generated method stub
		 return productDao.removeProductDetails(productId);
	}

	

	@Override
	public List<ProductDetails> viewProductDetails(int productId) throws GrizzlyException {
		// TODO Auto-generated method stub
		return productDao.viewProductDetails(productId);
	}

	@Override
	public int BlockProductDetails(int productId) throws ClassNotFoundException, GrizzlyException, SQLException {
		// TODO Auto-generated method stub
		return productDao.blockProductDetails(productId);
	}

	

}
