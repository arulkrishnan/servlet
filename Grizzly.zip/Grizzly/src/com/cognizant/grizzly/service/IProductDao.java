package com.cognizant.grizzly.service;

import java.sql.SQLException;
import java.util.List;

import com.cognizant.grizzly.exception.GrizzlyException;
import com.cognizant.grizzly.model.ProductDetails;

public interface IProductDao {

	public int saveProductDetails(ProductDetails productDetails) throws ClassNotFoundException, GrizzlyException, SQLException;
	public List<ProductDetails> getAllProductDetails() throws GrizzlyException;
	public  int removeProductDetails(int productId) throws ClassNotFoundException, GrizzlyException, SQLException;
	public int BlockProductDetails(int productId) throws ClassNotFoundException, GrizzlyException, SQLException;
	public List<ProductDetails> viewProductDetails(int productId) throws GrizzlyException;
	
}
