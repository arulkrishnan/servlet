package com.cognizant.grizzly.service;

import com.cognizant.grizzly.dao.LoginDao;
import com.cognizant.grizzly.exception.GrizzlyException;

import com.cognizant.grizzly.model.LoginDetails;

public class LoginService implements ILoginDao {

	LoginDao loginDao=LoginDao.getLoginDao();
	@Override
	public int checkLogin(LoginDetails loginDetails) throws GrizzlyException {
		// TODO Auto-generated method stub
		return loginDao.checkLogin(loginDetails);
	}

	@Override
	public int checkUserName(String Username) throws GrizzlyException {
		// TODO Auto-generated method stub
		return loginDao.checkUserName(Username);
	}

	@Override
	public int updateStatus(String username) throws GrizzlyException {
		// TODO Auto-generated method stub
		return loginDao.updateStatus(username);
	}

	@Override
	public int getStatus(String username) throws GrizzlyException {
		// TODO Auto-generated method stub
		return loginDao.getStatus(username);
	}

	

}
