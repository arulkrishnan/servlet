package com.cognizant.grizzly.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.grizzly.model.LoginDetails;
import com.cognizant.grizzly.model.ProductDetails;
import com.cognizant.grizzly.service.LoginService;
import com.cognizant.grizzly.service.ProductService;


/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int count=0;
		if(request.getParameter("submit").equals("login")) {
			
			String username=request.getParameter("name");
			String password=request.getParameter("password");
			LoginDetails loginDetails=new LoginDetails(username,password);
			LoginService loginService=new LoginService();
			try {
				int status=loginService.checkLogin(loginDetails);
				if(status==-1) {
					int status1=loginService.checkUserName(username);
				    if(status1==1) {
				    	int status2=loginService.getStatus(username);
				    	if(status2==1) {
				    	int attempt=loginService.updateStatus(username);
				    	}
				    	else {
				    		request.setAttribute("err", "Account is blocked");
				    		RequestDispatcher requestDispatcher=request.getRequestDispatcher("/jsp/login.jsp");
							requestDispatcher.forward(request, response);		
				    	}
				    }
				    
				    else {
					RequestDispatcher requestDispatcher=request.getRequestDispatcher("/jsp/login.jsp");
					requestDispatcher.forward(request, response);
				    }
				}
				else {
					HttpSession session=request.getSession();
					session.setAttribute("user", loginDetails);
                   
					ProductService productService=new ProductService();
					List<ProductDetails> list=productService.getAllProductDetails();
					request.setAttribute("prolist", list);
					RequestDispatcher requestDispatcher=request.getRequestDispatcher("/jsp/home.jsp");
					requestDispatcher.forward(request, response);
					
				}
				
			}
			
			catch (Exception e) {
				request.setAttribute("error",e. getMessage());
				RequestDispatcher requestDispatcher=request.getRequestDispatcher("/jsp/login.jsp");
				requestDispatcher.forward(request, response);
				e.printStackTrace();	
				
			}
			
		}
		
	}

}
