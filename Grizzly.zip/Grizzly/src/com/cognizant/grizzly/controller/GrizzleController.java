package com.cognizant.grizzly.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.grizzly.exception.GrizzlyException;
import com.cognizant.grizzly.model.ProductBrand;
import com.cognizant.grizzly.model.ProductCategory;
import com.cognizant.grizzly.model.ProductDetails;
import com.cognizant.grizzly.service.ProductService;


/**
 * Servlet implementation class GrizzleController
 */
@WebServlet("/GrizzleController")
public class GrizzleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Object ConnectionUtil;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GrizzleController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		if(request.getParameter("Add")!=null) {
			System.out.println("enter");
			String pid=request.getParameter("productid");
			int productId=Integer.parseInt(pid);
			
			String ctg=request.getParameter("category");
			int category=Integer.parseInt(ctg);
			
			System.out.println(ctg);
			String productDescription=request.getParameter("description");
			String pri=request.getParameter("price");
			Double productPrice=Double.parseDouble(pri);
		    String brand=request.getParameter("brand");
		    int brandId=Integer.parseInt(brand);
		    String productName=request.getParameter("productname");
			
		    String productImages[]=request.getParameterValues("filenames");
		    StringBuffer sb=new StringBuffer();
		    for(int i=0;i<productImages.length;i++) {
		    	sb.append(productImages[i]);
		    	sb.append(",");
		    }
		    sb.deleteCharAt(sb.length()-1);
			ProductCategory productCategory=new ProductCategory();
			productCategory.setCategoryId(category);
			 
			ProductBrand productBrand=new ProductBrand();
			productBrand.setBrandId(brandId);
			  
			ProductDetails productDetails=new ProductDetails(0, productName,  productDescription, productPrice,sb.toString(),
					 productBrand, productCategory);
			
			ProductService productService=new ProductService();
			int proid=0;
		
				try {
					proid=productService.saveProductDetails(productDetails);
					System.out.println("product saved");
					RequestDispatcher requestDispatcher =request.getRequestDispatcher("/jsp/product.jsp");
					requestDispatcher.forward(request, response);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
				
			
			
	
			
		}
      if(request.getParameter("View")!=null) {
			
			String proid=request.getParameter("productid");
			System.out.println("proiddddd"+proid);
			int productId=Integer.parseInt(proid);
			ProductService productDao=new ProductService();
			int count=0;
			try {
				
				System.out.println("product Viewed");
				List<ProductDetails> list=productDao.viewProductDetails(productId);
				request.setAttribute("product", list.get(0));
				RequestDispatcher requestDispatcher =request.getRequestDispatcher("/jsp/description2.jsp");
				requestDispatcher.forward(request, response);
			}
			
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}	
			
    	  
    	  
			
		}
	

		else if(request.getParameter("Block")!=null) {
			
			// TODO Auto-generated method stub
			String id=request.getParameter("productid");
			int productId=Integer.parseInt(id);
			System.out.println(productId);
			ProductService productService=new ProductService();
			int proid=0;
			
			try {
				proid=productService.BlockProductDetails(productId);
				System.out.println("product Blocked");
				List<ProductDetails> list=productService.getAllProductDetails();
				request.setAttribute("prolist", list);
				RequestDispatcher requestDispatcher =request.getRequestDispatcher("/jsp/home.jsp");
				requestDispatcher.forward(request, response);
			}
			
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}	
			
		}
		

		else if(request.getParameter("Finish")!=null) {
			
			// TODO Auto-generated method stub
			
			ProductService productDao=new ProductService();
		
			
			try {
				
				
				List<ProductDetails> list=productDao.getAllProductDetails();
				request.setAttribute("prolist", list);
				RequestDispatcher requestDispatcher =request.getRequestDispatcher("/jsp/home.jsp");
				requestDispatcher.forward(request, response);
			}
			
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
		}	
			
		}
      
      
		
		else {
       if(request.getParameter("Remove")!=null) {
    	   String id=request.getParameter("productid");
   		int productId=Integer.parseInt(id);
   		System.out.println(productId);
   		ProductService productDao=new ProductService();
   		
   		try {
   			productId=productDao.removeProductDetails(productId);
   			System.out.println("product Removed");
   			List<ProductDetails> list=productDao.getAllProductDetails();
			request.setAttribute("prolist", list);
   			RequestDispatcher requestDispatcher =request.getRequestDispatcher("/jsp/home.jsp");
   			requestDispatcher.forward(request, response);
   		}
   		
   	catch (Exception e) {
   		// TODO: handle exception
   		e.printStackTrace();
   		System.out.println(e.getMessage());
   	}	
			
	
			
		}
		}
		
	}

}
