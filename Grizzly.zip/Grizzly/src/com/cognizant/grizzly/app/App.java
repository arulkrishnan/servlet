package com.cognizant.grizzly.app;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.grizzly.model.LoginDetails;
import com.cognizant.grizzly.model.ProductBrand;
import com.cognizant.grizzly.model.ProductCategory;
import com.cognizant.grizzly.model.ProductDetails;
import com.cognizant.grizzly.service.LoginService;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("sprin-config.xml");
		LoginService loginService=context.getBean("loginService",LoginService.class);
		//System.out.println(loginService);
		
		//ProductDetails details=context.getBean("productDetails",ProductDetails.class);
		
		LoginDetails loginDetails=context.getBean("loginDetails",LoginDetails.class);
		System.out.println(loginDetails);
		ProductCategory productcategory=context.getBean("productCategory",ProductCategory.class);
		ProductBrand productBrand=context.getBean("productBrand",ProductBrand.class);
		ProductDetails productDetails=context.getBean("productDetails",ProductDetails.class);
		System.out.println(productDetails);
		
	}

}
