package com.cognizant.grizzly.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.grizzly.Util.ConnectionUtil;
import com.cognizant.grizzly.exception.GrizzlyException;
import com.cognizant.grizzly.exception.IGrizzlyMessages;
import com.cognizant.grizzly.model.ProductBrand;
import com.cognizant.grizzly.model.ProductCategory;
import com.cognizant.grizzly.model.ProductDetails;


public class ProductDao{
	
	private static ProductDao productDao;
	private ProductDao() {
		
	}
	
	public static ProductDao getProductDao() {
		if(productDao==null) {
			productDao=new ProductDao();
		}
		return productDao;
		
	}
	
	
public List<ProductDetails> getProductDetails() throws GrizzlyException
{
	List<ProductDetails> list=new ArrayList<>();
	Connection connObj=null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	String query="select p.*,pc.*,pb.*\r\n" + 
			"from product_details p join product_category pc join product_brand pb \r\n" + 
			"on p.pd_pc_fk=pc.pc_id and p.pd_pb_fk=pb.pb_id \r\n" + 
			"group by p.pd_id order by p.pd_name desc";
	try
	{   
		connObj=ConnectionUtil.getConnection();
		if(connObj==null)
		{
		System.out.println("not Got connection");
		}
	else {
		System.out.println("Got Connected");
	}
		
		preparedStatement = connObj.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
 
 
	
	resultSet = preparedStatement.executeQuery();
	while(resultSet.next())
	{	
		int productId=resultSet.getInt("PD_ID");
		String productName =resultSet.getString("PD_NAME");
	    double price=resultSet.getDouble("PD_PRICE"); 
	    int productRating=resultSet.getInt("PD_RATING");
	    String description=resultSet.getString("PD_DESCRIPTION");
	    
	    int categoryId=resultSet.getInt("PC_ID"); 
	    String categoryName=resultSet.getString("PC_NAME");
	    
	    ProductCategory productCategory=new ProductCategory(categoryId,categoryName);
	    
	    String productImages=resultSet.getString("pd_images");
	    int brandId=resultSet.getInt("PB_ID");
	    String brandName =resultSet.getString("PB_NAME");
	    
	    ProductBrand productBrands=new ProductBrand(brandId,brandName);	 
	    ProductDetails productDetails=new ProductDetails(productId,  productName, description, price,
	    		 productRating,productImages,productBrands, productCategory);
		   // add employee to list
		list.add(productDetails);
		
		//System.out.println("Welcome-->"+uname);
	//http://10.223.70.118/courses/web/index.html	
	}
	
	}
	catch(ClassNotFoundException classNotFoundException)
	{
		classNotFoundException.printStackTrace();
		//classNotFoundException.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.DRIVER_MISSING_ERROR);
	}
	catch(SQLException sqlException)
	{
		sqlException.printStackTrace();
		//classNotFoundException.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.SOME_SQL_ERROR);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.CONTACT_TO_ADMIN_ERROR);
		}
	     finally {
			try {
			if(resultSet!=null)
				resultSet.close();
			if(preparedStatement!=null)
				preparedStatement.close();
			if(connObj!=null)
				connObj.close();
			}catch(SQLException exception) {
			exception.printStackTrace();
			throw new GrizzlyException(IGrizzlyMessages.CLOSING_RESOURCE_ERROR);
			
		}
}
	return list;
}



public int saveProductDetails(ProductDetails productDetails) throws GrizzlyException, ClassNotFoundException, SQLException {
	

    Connection connObj = null;
	connObj = ConnectionUtil.getConnection();
	
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	 int productId=0;
	String query = "insert into product_details (pd_id,pd_name,pd_description,pd_price,pd_available,pd_rating,pd_pb_fk,pd_pc_fk,pd_images) "
			+ "values (?,?,?,?,?,?,?,?,?)";
	try {
		connObj=ConnectionUtil.getConnection();
		if (connObj == null) {
			System.out.println("not Got connection");
		} else {
			System.out.println("Got Connected");
		}
		preparedStatement = connObj.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

		preparedStatement.setInt(1, productDetails.getProductId());
		preparedStatement.setString(2, productDetails.getProductName());
		preparedStatement.setString(3, productDetails.getProductDescription());
		preparedStatement.setDouble(4, productDetails.getProductPrice());
		preparedStatement.setInt(5, 1);
		preparedStatement.setInt(6, 0);
		preparedStatement.setInt(7, productDetails.getProductBrands().getBrandId());
		preparedStatement.setInt(8, productDetails.getProductCategory().getCategoryId());
		preparedStatement.setString(9, productDetails.getproductImages());

		int count = preparedStatement.executeUpdate();
       
		resultSet = preparedStatement.getGeneratedKeys();
		if (resultSet.next()) {
			productId = resultSet.getInt(1);
		}
		
		if (count >= 1) {
			System.out.println("Employee is save");
		} else {

			throw new GrizzlyException("Employee is not saved some internal error");
		}

		/*
		 * if(resultSet!=null) resultSet.close();
		 */

	} catch (SQLException sqlException) {
		sqlException.printStackTrace();
		//classNotFoundException.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.SOME_SQL_ERROR);
	} catch (Exception e) {
		e.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.CONTACT_TO_ADMIN_ERROR);
	} finally {
		if (preparedStatement != null) {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GrizzlyException(e.getMessage());
			}

		}
		
		 if(connObj!=null) { connObj.close(); }
		 

	}

	return productId;
	
	
}


public int removeProductDetails(int productId) throws GrizzlyException, ClassNotFoundException, SQLException {
	

    Connection connObj = null;
	connObj = ConnectionUtil.getConnection();
	
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	 int prodId=0;
	String query = "delete from product_details where pd_id=?";
			
	try {
		connObj=ConnectionUtil.getConnection();
		if (connObj == null) {
			System.out.println("not Got connection");
		} else {
			System.out.println("Got Connected");
		}
		preparedStatement = connObj.prepareStatement(query);

		preparedStatement.setInt(1, productId);
		
		

		int count = preparedStatement.executeUpdate();
       
		/*resultSet = preparedStatement.getGeneratedKeys();
		if (resultSet.next()) {
			prodId = resultSet.getInt(1);
		}
		
		if (count >= 1) {
			System.out.println("product is removed");
		} else {

			throw new GrizzlyException("product is not removed some internal error");
		}

		/*
		 * if(resultSet!=null) resultSet.close();
		 */

	} catch (SQLException sqlException) {
		sqlException.printStackTrace();
		//classNotFoundException.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.SOME_SQL_ERROR);
	} catch (Exception e) {
		e.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.CONTACT_TO_ADMIN_ERROR);
	} finally {
		if (preparedStatement != null) {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GrizzlyException(e.getMessage());
			}

		}
		
		 if(connObj!=null) { connObj.close(); }
		 

	}

	return productId;
	
	
}

public int blockProductDetails(int productId) throws GrizzlyException, ClassNotFoundException, SQLException {
	

    Connection connObj = null;
	connObj = ConnectionUtil.getConnection();
	System.out.println("pid"+productId);
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	 int count=0;
	String query = "update product_details set pd_available=0 where pd_id=?";
			
	try {
		connObj=ConnectionUtil.getConnection();
		if (connObj == null) {
			System.out.println("not Got connection");
		} else {
			System.out.println("Got Connected");
		}
		preparedStatement = connObj.prepareStatement(query);

	
		preparedStatement.setInt(1, productId);
		
		

		 count = preparedStatement.executeUpdate();
       
		/*resultSet = preparedStatement.getGeneratedKeys();
		if (resultSet.next()) {
			prodId = resultSet.getInt(1);
		}*/
		
		if (count >= 1) {
			System.out.println("product is blocked");
		} else {

			throw new GrizzlyException("product is not blocked some internal error");
		}

		/*
		 * if(resultSet!=null) resultSet.close();
		 */

	} catch (SQLException sqlException) {
		sqlException.printStackTrace();
		//classNotFoundException.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.SOME_SQL_ERROR);
	} catch (Exception e) {
		e.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.CONTACT_TO_ADMIN_ERROR);
	} finally {
		if (preparedStatement != null) {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GrizzlyException(e.getMessage());
			}

		}
		
		 if(connObj!=null) { connObj.close(); }
		 

	}

	return count;
	
	
}

public List<ProductDetails> viewProductDetails(int productId) throws GrizzlyException
{
	List<ProductDetails> list=new ArrayList<>();
	Connection connObj=null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	String query="select p.*,pc.*,pb.*\r\n" + 
			"from product_details p join product_category pc join product_brand pb \r\n" + 
			"on p.pd_pc_fk=pc.pc_id and p.pd_pb_fk=pb.pb_id \r\n" + "where pd_id=? \r\n"+
			"group by p.pd_id order by p.pd_name desc";
			
	try
	{   
		connObj=ConnectionUtil.getConnection();
		if(connObj==null)
		{
		System.out.println("not Got connection");
		}
	else {
		System.out.println("Got Connected");
	}
		
		preparedStatement = connObj.prepareStatement(query);
		preparedStatement.setInt(1, productId);
	
	resultSet = preparedStatement.executeQuery();
	while(resultSet.next())
	{	
		int proId=resultSet.getInt("PD_ID");
		String productName =resultSet.getString("PD_NAME");
	    double price=resultSet.getDouble("PD_PRICE"); 
	    int productRating=resultSet.getInt("PD_RATING");
	    String description=resultSet.getString("PD_DESCRIPTION");
	    int categoryId=resultSet.getInt("PC_ID"); 
	   String categoryName=resultSet.getString("PC_NAME");
	    
	    ProductCategory productCategory=new ProductCategory(categoryId,categoryName);
	    
	    int brandId=resultSet.getInt("PB_ID");
	    String brandName =resultSet.getString("PB_NAME");
	    
	    String productImages=resultSet.getString("pd_images");
	    
	    ProductBrand productBrands=new ProductBrand(brandId,brandName);	 
	    ProductDetails productDetails=new ProductDetails(proId,  productName, description, price,
	    		 productRating,productImages,productBrands, productCategory);
		   // add employee to list
		list.add(productDetails);
		
		//System.out.println("Welcome-->"+uname);
	//http://10.223.70.118/courses/web/index.html	
	}
	
	}
	catch(ClassNotFoundException classNotFoundException)
	{
		classNotFoundException.printStackTrace();
		//classNotFoundException.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.DRIVER_MISSING_ERROR);
	}
	catch(SQLException sqlException)
	{
		sqlException.printStackTrace();
		//classNotFoundException.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.SOME_SQL_ERROR);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		throw new GrizzlyException(IGrizzlyMessages.CONTACT_TO_ADMIN_ERROR);
		}
	     finally {
			try {
			if(resultSet!=null)
				resultSet.close();
			if(preparedStatement!=null)
				preparedStatement.close();
			if(connObj!=null)
				connObj.close();
			}catch(SQLException exception) {
			exception.printStackTrace();
			throw new GrizzlyException(IGrizzlyMessages.CLOSING_RESOURCE_ERROR);
			
		}
}
	return list;


}
}