package com.cognizant.grizzly.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cognizant.grizzly.Util.ConnectionUtil;
import com.cognizant.grizzly.exception.GrizzlyException;
import com.cognizant.grizzly.exception.IGrizzlyMessages;
import com.cognizant.grizzly.model.LoginDetails;
import com.cognizant.grizzly.service.ILoginDao;


public class LoginDao implements ILoginDao{
	
	private static LoginDao loginDao;
	private LoginDao() {
		
	}
	
	public static LoginDao getLoginDao() {
		if(loginDao==null) {
			loginDao=new LoginDao();
		}
		return loginDao;
		
	}
	

	public int checkLogin(LoginDetails loginDetails) throws GrizzlyException {
		
		Connection connObj=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String user="";
		try {
			connObj=ConnectionUtil.getConnection();
			if(connObj==null) {
				System.out.println("connection not established");
			}
			
			else {
				System.out.println("connection established1");
			}
			
				preparedStatement=connObj.prepareStatement("select username,password from login where username=? AND password=?");
				preparedStatement.setString(1, loginDetails.getUsername());
				preparedStatement.setString(2, loginDetails.getPassword());
				resultSet=preparedStatement.executeQuery();
				
				if(resultSet!=null) {
					resultSet.next();
					user=resultSet.getString("username");
				}
				
				
				else {
					if(resultSet!=null)
						resultSet.close();
					if(preparedStatement!=null)
						preparedStatement.close();
					if(connObj!=null)
						connObj.close();
					return -1;
				}
				/*preparedStatement=connObj.prepareStatement("update login set count=0 where username=?");
				preparedStatement.setString(1, loginDetails.getUsername());
				int count=preparedStatement.executeUpdate();*/
					
				
		}
			catch (ClassNotFoundException classNotFoundException) {
				classNotFoundException.printStackTrace();
				throw new GrizzlyException(IGrizzlyMessages.DRIVER_MISSING_ERROR);
				
			}
		
		catch (SQLException sqlException ) {
			sqlException.printStackTrace();
			throw new GrizzlyException(IGrizzlyMessages.SOME_SQL_ERROR);
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw new GrizzlyException(IGrizzlyMessages.CONTACT_TO_ADMIN_ERROR);
			
		}
		
		
		return 1;
		
	}

	
	
	
	
	@Override
	public int checkUserName(String username) throws GrizzlyException {
		Connection connObj=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String user="";
		try {
			connObj=ConnectionUtil.getConnection();
			if(connObj==null) {
				System.out.println("connection not established");
			}
			
			else {
				System.out.println("connection established2");
			}
			
				preparedStatement=connObj.prepareStatement("select username from login where username=?");
				preparedStatement.setString(1, username);
				resultSet=preparedStatement.executeQuery();
				if(resultSet!=null) {
					resultSet.next();
					user=resultSet.getString("username");
				}
				
				else {
					return -1;
				}
				System.out.println(user);
					if(resultSet!=null)
						resultSet.close();
					if(preparedStatement!=null)
						preparedStatement.close();
					if(connObj!=null)
						connObj.close();
				
		}
			catch (ClassNotFoundException classNotFoundException) {
				//classNotFoundException.printStackTrace();
				throw new GrizzlyException(IGrizzlyMessages.DRIVER_MISSING_ERROR);
				
			}
		
		catch (SQLException sqlException) {
			//classNotFoundException.printStackTrace();
			throw new GrizzlyException(IGrizzlyMessages.SOME_SQL_ERROR);
			
		}
		
		catch (Exception e) {
			//classNotFoundException.printStackTrace();
			throw new GrizzlyException(IGrizzlyMessages.CONTACT_TO_ADMIN_ERROR);
			
		}
		
		
	
		return 1;
			
	}
	
	
	

	@Override
	public int updateStatus(String username) throws GrizzlyException {
	
		Connection connObj=null;
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet=null;
		ResultSet resultSet1=null;
		String user="";
		try {
			connObj=ConnectionUtil.getConnection();
			if(connObj==null) {
				System.out.println("connection not established");
			}
			
			else {
				System.out.println("connection established3");
			}
			    int attempt=0;
			   
			  /*  preparedStatement=connObj.prepareStatement("select attempt from login where user=?");
			    preparedStatement.setString(1, username);
			    resultSet=preparedStatement.executeQuery();
			    if(resultSet.next()){
			     attempt=resultSet.getInt("attempt");
			     String uname=resultSet.getString("user");
			     System.out.println(uname);
			    }
			
			    System.out.println(attempt);
			    attempt=attempt+1;*/
			    int c=0;
				preparedStatement1=connObj.prepareStatement("update login SET count=count+1 where username=?");
				/*preparedStatement1=connObj.prepareStatement("select count from login");
				resultSet=preparedStatement.executeQuery();
				if(resultSet.next()) {
					c=resultSet.getInt("count");
				}
				System.out.println(username);
				System.out.println(c);*/
		
				
		
				preparedStatement1.setString(1, username);
			int count=	preparedStatement1.executeUpdate();
					if(resultSet!=null)
						resultSet.close();
					if(preparedStatement1!=null)
						preparedStatement1.close();
					if(connObj!=null)
						connObj.close();
					if(resultSet1!=null)
						resultSet1.close();
					if(preparedStatement!=null)
						preparedStatement.close();
		}
			catch (ClassNotFoundException classNotFoundException) {
				classNotFoundException.printStackTrace();
				throw new GrizzlyException(IGrizzlyMessages.DRIVER_MISSING_ERROR);
				
			}
		
		catch (SQLException sqlException) {
			sqlException.printStackTrace();
			throw new GrizzlyException(IGrizzlyMessages.SOME_SQL_ERROR);
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw new GrizzlyException(IGrizzlyMessages.CONTACT_TO_ADMIN_ERROR);
			
		}
		
		
		return 1;
	}
	
	

	@Override
	public int getStatus(String username) throws GrizzlyException {
		Connection connObj=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String user="";
		try {
			connObj=ConnectionUtil.getConnection();
			if(connObj==null) {
				System.out.println("connection not established");
			}
			
			else {
				System.out.println("connection established4");
			}
			
				preparedStatement=connObj.prepareStatement("select username from login where username=? AND count < ?");
				preparedStatement.setString(1, username);
				int atp=3;
				preparedStatement.setInt(2, atp);
				resultSet=preparedStatement.executeQuery();
				if(resultSet!=null) {
					resultSet.next();
					user=resultSet.getString("username");
				}
				else {
					return -1;
				}
					if(resultSet!=null)
						resultSet.close();
					if(preparedStatement!=null)
						preparedStatement.close();
					if(connObj!=null)
						connObj.close();
				
		}
			catch (ClassNotFoundException classNotFoundException) {
				//classNotFoundException.printStackTrace();
				throw new GrizzlyException(IGrizzlyMessages.DRIVER_MISSING_ERROR);
				
			}
		
		catch (SQLException sqlException) {
			//classNotFoundException.printStackTrace();
			throw new GrizzlyException(IGrizzlyMessages.SOME_SQL_ERROR);
			
		}
		
		catch (Exception e) {
			//classNotFoundException.printStackTrace();
			throw new GrizzlyException(IGrizzlyMessages.CONTACT_TO_ADMIN_ERROR);
			
		}
		
		return 1;
	}
	
	
}
