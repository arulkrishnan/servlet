package com.cognizant.grizzly.model;

public class ProductDetails {
  private int productId;
  private String productName;
  private String productDescription;
  private double productPrice;
  private double productRating;
  private String productImages;
  
  
  
public ProductDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public ProductDetails(int productId, String productName, String productDescription, double productPrice,
		double productRating, String productImages,ProductBrand productBrands, ProductCategory productCategory) {
	super();
	this.productId = productId;
	this.productName = productName;
	this.productDescription = productDescription;
	this.productPrice = productPrice;
	this.productRating = productRating;
	this.productBrands = productBrands;
	this.productCategory = productCategory;
	this.productImages=productImages;
}

public String getproductImages() {
	return productImages;
}
public void setproductImages(String productImages) {
	productImages = productImages;
}
public ProductDetails(int productId, String productName, String productDescription, double productPrice, String productImages,
		 ProductBrand productBrands, ProductCategory productCategory) {
	super();
	this.productId = productId;
	this.productName = productName;
	this.productDescription = productDescription;
	this.productPrice = productPrice;
	this.productBrands = productBrands;
	this.productCategory = productCategory;
	this.productImages=productImages;
}
@Override
public String toString() {
	return "ProductDetails [productId=" + productId + ", productName=" + productName + ", productDescription="
			+ productDescription + ", productPrice=" + productPrice + ", productRating=" + productRating
			+ ", productBrands=" + productBrands + ", productCategory=" + productCategory + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((productBrands == null) ? 0 : productBrands.hashCode());
	result = prime * result + ((productCategory == null) ? 0 : productCategory.hashCode());
	result = prime * result + ((productDescription == null) ? 0 : productDescription.hashCode());
	result = prime * result + productId;
	result = prime * result + ((productName == null) ? 0 : productName.hashCode());
	long temp;
	temp = Double.doubleToLongBits(productPrice);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	temp = Double.doubleToLongBits(productRating);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	ProductDetails other = (ProductDetails) obj;
	if (productBrands == null) {
		if (other.productBrands != null)
			return false;
	} else if (!productBrands.equals(other.productBrands))
		return false;
	if (productCategory == null) {
		if (other.productCategory != null)
			return false;
	} else if (!productCategory.equals(other.productCategory))
		return false;
	if (productDescription == null) {
		if (other.productDescription != null)
			return false;
	} else if (!productDescription.equals(other.productDescription))
		return false;
	if (productId != other.productId)
		return false;
	if (productName == null) {
		if (other.productName != null)
			return false;
	} else if (!productName.equals(other.productName))
		return false;
	if (Double.doubleToLongBits(productPrice) != Double.doubleToLongBits(other.productPrice))
		return false;
	if (Double.doubleToLongBits(productRating) != Double.doubleToLongBits(other.productRating))
		return false;
	return true;
}
public int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getProductDescription() {
	return productDescription;
}
public void setProductDescription(String productDescription) {
	this.productDescription = productDescription;
}
public double getProductPrice() {
	return productPrice;
}
public void setProductPrice(double productPrice) {
	this.productPrice = productPrice;
}
public double getProductRating() {
	return productRating;
}
public void setProductRating(double productRating) {
	this.productRating = productRating;
}
public ProductBrand getProductBrands() {
	return productBrands;
}
public void setProductBrands(ProductBrand productBrands) {
	this.productBrands = productBrands;
}
public ProductCategory getProductCategory() {
	return productCategory;
}
public void setProductCategory(ProductCategory productCategory) {
	this.productCategory = productCategory;
}
private ProductBrand productBrands;
  private ProductCategory productCategory;
	
}
