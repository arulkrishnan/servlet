package com.cognizant.grizzly.model;

public class VendorDetails {

	private int quantity;
	private ProductDetails productDetails;
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public ProductDetails getProductDetails() {
		return productDetails;
	}
	public void setProductDetails(ProductDetails productDetails) {
		this.productDetails = productDetails;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((productDetails == null) ? 0 : productDetails.hashCode());
		result = prime * result + quantity;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VendorDetails other = (VendorDetails) obj;
		if (productDetails == null) {
			if (other.productDetails != null)
				return false;
		} else if (!productDetails.equals(other.productDetails))
			return false;
		if (quantity != other.quantity)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "VendorDetails [quantity=" + quantity + ", productDetails=" + productDetails + "]";
	}
	public VendorDetails(int quantity, ProductDetails productDetails) {
		super();
		this.quantity = quantity;
		this.productDetails = productDetails;
	}
	public VendorDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
