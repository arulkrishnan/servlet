package com.cognizant.grizzly.model;

public class ProductCategory {

	
	private int CategoryId;
	public ProductCategory() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductCategory(int categoryId, String categoryName) {
		super();
		CategoryId = categoryId;
		CategoryName = categoryName;
	}
	@Override
	public String toString() {
		return "ProductCategory [CategoryId=" + CategoryId + ", CategoryName=" + CategoryName + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + CategoryId;
		result = prime * result + ((CategoryName == null) ? 0 : CategoryName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductCategory other = (ProductCategory) obj;
		if (CategoryId != other.CategoryId)
			return false;
		if (CategoryName == null) {
			if (other.CategoryName != null)
				return false;
		} else if (!CategoryName.equals(other.CategoryName))
			return false;
		return true;
	}
	private String CategoryName;
	public int getCategoryId() {
		return CategoryId;
	}
	public void setCategoryId(int categoryId) {
		CategoryId = categoryId;
	}
	public String getCategoryName() {
		return CategoryName;
	}
	public void setCategoryName(String categoryName) {
		CategoryName = categoryName;
	}
	
}
