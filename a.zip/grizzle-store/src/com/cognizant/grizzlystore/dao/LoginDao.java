package com.cognizant.grizzlystore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cognizant.grizzlystore.exception.GrizzlyStoreException;
import com.cognizant.grizzlystore.exception.IGrizzlyStoreMessages;
import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.Validation;
import com.cognizant.grizzlystore.util.ConnectionUtil;

public class LoginDao {

	public LoginDao() {
		// TODO Auto-generated constructor stub
	}

	@SuppressWarnings("resource")
	public boolean doLogin(LoginDetails loginDetails) throws GrizzlyStoreException,Exception {
		// TODO Auto-generated method stub
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="";
		boolean usernameFlag=false;
		boolean passwordFlag=false;
		boolean statusFlag=false;
		try {
			connection=ConnectionUtil.getConnection();
			sql="SELECT * FROM login WHERE username=?;";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, loginDetails.getUsername());
			//System.out.println(connection);
			resultSet=preparedStatement.executeQuery();
			if(resultSet!=null) {
				resultSet.next();
				usernameFlag=Validation.isUsernameValid(resultSet.getString("username"), loginDetails.getUsername());
				passwordFlag=Validation.isPasswordValid(resultSet.getString("password"), loginDetails.getPassword());
				statusFlag=Validation.isStatusValid(resultSet.getInt("attempt"));
				loginDetails.setUserType(resultSet.getString("user_type"));
				if(usernameFlag && passwordFlag && statusFlag) {
					sql="UPDATE login SET attempt=? WHERE username=?;";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setInt(1, 0);
					preparedStatement.setString(2, loginDetails.getUsername());
					preparedStatement.executeUpdate();
					return true;
				}
				else if(!statusFlag) {
					System.out.println("Maximum attempt excedded;");
					throw new GrizzlyStoreException(IGrizzlyStoreMessages.ATTEMPTEXCEDDED);
				}
				else if(!passwordFlag) {
					/*sql="SELECT attempt FROM login WHERE username=?;";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setString(1, loginDetails.getUsername());
					resultSet=preparedStatement.executeQuery();
					resultSet.next();*/
					int attempt=resultSet.getInt("attempt");
					sql="UPDATE login SET attempt=? WHERE username=?;";
					preparedStatement=connection.prepareStatement(sql);
					attempt++;
					preparedStatement.setInt(1, attempt);
					preparedStatement.setString(2, loginDetails.getUsername());
					preparedStatement.executeUpdate();
					throw new GrizzlyStoreException(IGrizzlyStoreMessages.USERERROR);
				}
			}
			else {
				throw new GrizzlyStoreException(IGrizzlyStoreMessages.SQL);
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			//System.out.println(usernameFlag);
			//System.out.println(passwordFlag);
			//System.out.println(statusFlag);
			if(connection!=null)
				connection.close();
			if(preparedStatement!=null)
				preparedStatement.close();
			if(resultSet!=null)
				resultSet.close();
		}
		return false;
	}
	

}
