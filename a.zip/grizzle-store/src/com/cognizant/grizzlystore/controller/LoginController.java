package com.cognizant.grizzlystore.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.service.AddProductService;
import com.cognizant.grizzlystore.service.EditProductService;
import com.cognizant.grizzlystore.service.LoginService;
import com.cognizant.grizzlystore.service.ProductService;

	@Controller
	public class LoginController {

	@RequestMapping(value="/home", method=RequestMethod.GET)
	String home() {
		return "Login";
	}
	
	@RequestMapping(value="/LoginController", method=RequestMethod.POST)
	public ModelAndView login(LoginDetails loginDetails, HttpServletRequest request) {
		ModelAndView modelAndView=null;
		ProductService service = new ProductService();
		LoginService service2 = new LoginService();
		try {
			boolean dbLogin = service2.doLogin(loginDetails);
			if(dbLogin) {
				HttpSession session = request.getSession();
				session.setAttribute("user", loginDetails);
				List<ProductDetails> list = service.getProductDetails();
				modelAndView = new ModelAndView("ListProduct");
				modelAndView.addObject("productList",list);
			}
			else {
				modelAndView = new ModelAndView("Login");
				modelAndView.addObject("error","Username or password is wrong");
			}
				
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return modelAndView;
	}
	
	@RequestMapping(value="/ListController", method=RequestMethod.GET)
	public ModelAndView view(HttpServletRequest request) {
		ModelAndView modelAndView=null;
		ProductService service = new ProductService();
		try {
			boolean dbLogin = true;
			if(dbLogin) {
				List<ProductDetails> list = service.getProductDetails();
				modelAndView = new ModelAndView("ListProduct");
				modelAndView.addObject("productList",list);
			}
			else {
				modelAndView = new ModelAndView("Login");
				modelAndView.addObject("error","Username or password is wrong");
			}
				
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return modelAndView;
	}
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	String addproductPage() {
		return "AddProduct";
	}
	
	@RequestMapping(value="/AddProductController", method=RequestMethod.POST)
	public ModelAndView addProduct(ProductDetails productDetails, ModelAndView modelAndView, String[] image,String option) {
		if(option.equals("Add")) {
			if(productDetails!=null) {
				AddProductService addProductService=new AddProductService();
				try {
					String imagePath="";
					for(int i=0;i<image.length;i++) {
						if(i==0) {
							imagePath+=image[i];
						}
						else {
							imagePath+=","+image[i];
						}
					}
					productDetails.setImagePath(imagePath);
					boolean isSuccess=addProductService.addProduct(productDetails);
					if(isSuccess) {
						modelAndView = new ModelAndView("Success");
						modelAndView.addObject("message", "Successfully inserted!!!");
					}
					else {
						modelAndView = new ModelAndView("Success");
						modelAndView.addObject("message", "Data insertion failed, Please retry!!!");
					}
				}
				catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
			}
		}
		else if(option.equals("Cancel")) {
			modelAndView = new ModelAndView("ViewProduct");
		}
		return modelAndView;
	}
	
	@RequestMapping(value="/EditProductController", method=RequestMethod.POST)
	public ModelAndView editProduct(ModelAndView modelAndView, String[] productId,String option) {
		if(productId!=null) {
			EditProductService editProductService=new EditProductService();
			if(option.equals("View")) {
				List<ProductDetails> list=editProductService.viewProduct(productId);
				modelAndView = new ModelAndView("ViewProduct");
				modelAndView.addObject("productList", list);
			}
			else if(option.equals("Block")) {
				boolean bool=editProductService.blockProduct(productId);
				if(bool) {
					modelAndView = new ModelAndView("Success");
					modelAndView.addObject("message", "Product has been blocked successfully based on your request!!!");
				}
				else {
					modelAndView = new ModelAndView("Success");
					modelAndView.addObject("message", "Product has been block failure, Please retry!!!");
				}
			}
			else if(option.equals("Remove")) {
				boolean bool=editProductService.removeProduct(productId);
				if(bool) {
					modelAndView = new ModelAndView("Success");
					modelAndView.addObject("message", "Product has been removed successfully based on your request!!!");
				}
				else {
					modelAndView = new ModelAndView("Success");
					modelAndView.addObject("message", "Product has been remove failure, Please retry!!!");
				}
			}
			return modelAndView;
		}
		else {
			return null;
		}
	}
	
	@RequestMapping(value="/LogoutController", method=RequestMethod.POST)
	public String logoutController(ModelAndView modelAndView, HttpServletRequest request) {
		HttpSession httpSession = request.getSession(false);
		httpSession.invalidate();
		return "redirect:home";
	}
}