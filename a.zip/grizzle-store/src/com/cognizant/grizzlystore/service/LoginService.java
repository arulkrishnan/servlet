package com.cognizant.grizzlystore.service;

import com.cognizant.grizzlystore.dao.LoginDao;
import com.cognizant.grizzlystore.exception.GrizzlyStoreException;
import com.cognizant.grizzlystore.model.LoginDetails;

public class LoginService implements ILoginDao {

	LoginDao loginDao=new LoginDao();
	@Override
	public boolean doLogin(LoginDetails loginDetails) throws GrizzlyStoreException, Exception {
		// TODO Auto-generated method stub
		return loginDao.doLogin(loginDetails);
	}

}
