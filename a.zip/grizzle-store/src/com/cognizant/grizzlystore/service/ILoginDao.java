package com.cognizant.grizzlystore.service;

import com.cognizant.grizzlystore.exception.GrizzlyStoreException;
import com.cognizant.grizzlystore.model.LoginDetails;

public interface ILoginDao {

	public boolean doLogin(LoginDetails loginDetails) throws GrizzlyStoreException,Exception;
}
