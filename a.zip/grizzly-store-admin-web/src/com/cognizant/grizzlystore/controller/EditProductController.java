package com.cognizant.grizzlystore.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.service.EditProductService;

/**
 * Servlet implementation class EditProductController
 */
@WebServlet("/EditProductController")
public class EditProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getParameter("View")!=null) {
			String productId=request.getParameter("productId");
			EditProductService editProductService=new EditProductService();
			List<ProductDetails> list=editProductService.viewProduct(productId);
			request.setAttribute("productList",list);
			RequestDispatcher requestDispatcher=request.getRequestDispatcher("/jsp/ViewProduct.jsp");
			requestDispatcher.include(request, response);
		}
		else if(request.getParameter("Block")!=null) {
			String productIds[]=request.getParameterValues("productId");
			EditProductService editProductService=new EditProductService();
			editProductService.blockProduct(productIds);
			request.setAttribute("message", "Product has been blocked successfully!!!");
			RequestDispatcher requestDispatcher=request.getRequestDispatcher("/jsp/Success.jsp");
			requestDispatcher.include(request, response);
		}
		else if(request.getParameter("Remove")!=null) {
			String productIds[]=request.getParameterValues("productId");
			EditProductService editProductService=new EditProductService();
			editProductService.removeProduct(productIds);
			request.setAttribute("message", "Product has been removed successfully!!!");
			RequestDispatcher requestDispatcher=request.getRequestDispatcher("/jsp/Success.jsp");
			requestDispatcher.include(request, response);
		}
	}

}
