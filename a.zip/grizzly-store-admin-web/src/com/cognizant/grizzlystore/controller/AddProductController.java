	package com.cognizant.grizzlystore.controller;
	
	import java.io.IOException;
	
	import javax.servlet.RequestDispatcher;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

import com.cognizant.grizzlystore.exception.GrizzlyStoreException;
import com.cognizant.grizzlystore.model.Validation;
import com.cognizant.grizzlystore.service.AddProductService;
	/**
	 * Servlet implementation class AddProductController
	 */
	@WebServlet("/AddProductController")
	public class AddProductController extends HttpServlet {
		private static final long serialVersionUID = 1L;
	       
	    /**
	     * @see HttpServlet#HttpServlet()
	     */
	    public AddProductController() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
	
		/**
		 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
		 */
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
	
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
		 */
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			if(request.getParameter("add")!=null) {
				//int productId=Integer.parseInt(request.getParameter("product_id"));
				String productName=request.getParameter("product_name");
				String productCategory=request.getParameter("category");
				String productDescription=request.getParameter("product_description");
				float productPrice=Float.parseFloat(request.getParameter("product_price"));
				String productBrand=request.getParameter("brand");
				float rating=Float.parseFloat(request.getParameter("rating"));
				int categoryId=Validation.checkCategoryId(productCategory);
				int brandId=Validation.checkBrandId(productBrand);
				String[] images=request.getParameterValues("imagefile");
				String imagePath="";
				for(int i=0;i<images.length;i++) {
					if(i==0)
						imagePath+=images[i];
					else
						imagePath+=","+images[i];
				}
				AddProductService addProductService=new AddProductService();
				boolean status = false;
				try {
					status = addProductService.addProduct(productName,productBrand,productCategory,productDescription,productPrice,categoryId,brandId,rating,imagePath);
				} catch (GrizzlyStoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(status) {
					request.setAttribute("message", "Your data is inserted sucessfully!!!!");
					RequestDispatcher requestDispatcher=request.getRequestDispatcher("/jsp/Success.jsp");
					requestDispatcher.include(request, response);
				}
			}
			if(request.getParameter("cancel")!=null) {
				request.setAttribute("message", "Your request for add product is cancelled by you!!!!!!");
				RequestDispatcher requestDispatcher=request.getRequestDispatcher("/jsp/Success.jsp");
				requestDispatcher.include(request, response);
			}
		}
	
	}
