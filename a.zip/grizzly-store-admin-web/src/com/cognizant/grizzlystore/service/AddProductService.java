package com.cognizant.grizzlystore.service;

import com.cognizant.grizzlystore.dao.AddProductDao;
import com.cognizant.grizzlystore.exception.GrizzlyStoreException;

public class AddProductService implements IAddProductDao {

	AddProductDao addProductDao=new AddProductDao();
	@Override
	public boolean addProduct(String productName, String productBrand, String productCategory,
			String productDescription, float productPrice, int categoryId, int brandId, float rating,
			String imagePath) throws GrizzlyStoreException {
		// TODO Auto-generated method stub
		return addProductDao.addProduct(productName, productBrand, productCategory, productDescription, productPrice, categoryId, brandId, rating, imagePath);
	}

}
