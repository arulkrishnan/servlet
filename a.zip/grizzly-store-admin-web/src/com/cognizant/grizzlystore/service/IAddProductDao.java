package com.cognizant.grizzlystore.service;

import com.cognizant.grizzlystore.exception.GrizzlyStoreException;

public interface IAddProductDao {
	
	public boolean addProduct(String productName, String productBrand, String productCategory, String productDescription, float productPrice, int categoryId, int brandId, float rating, String imagePath) throws GrizzlyStoreException;
	

}
