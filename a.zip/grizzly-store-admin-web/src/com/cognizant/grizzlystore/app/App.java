package com.cognizant.grizzlystore.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductBrand;
import com.cognizant.grizzlystore.model.ProductCategory;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.service.LoginService;

public class App {

	public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
        LoginService loginService=context.getBean("loginService",LoginService.class);
        //System.out.println(loginService);
        
        //ProductDetails details=context.getBean("productDetails",ProductDetails.class);
        
        LoginDetails loginDetails=context.getBean("loginDetails",LoginDetails.class);
        ProductCategory productcategory=context.getBean("productCategory",ProductCategory.class);
        ProductBrand productBrand=context.getBean("productBrand",ProductBrand.class);
        ProductDetails productDetails=context.getBean("productDetails",ProductDetails.class);
        System.out.println(productDetails);
        System.out.println(productBrand);
        System.out.println(productcategory);
        System.out.println(loginDetails);
        System.out.println(loginService);
	}
}
