package com.cognizant.grizzlystore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cognizant.grizzlystore.exception.GrizzlyStoreException;
import com.cognizant.grizzlystore.util.ConnectionUtil;

public class AddProductDao {

	public boolean addProduct(String productName, String productBrand, String productCategory, String productDescription, float productPrice, int categoryId, int brandId, float rating, String imagePath) throws GrizzlyStoreException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="";
		try {
			connection=ConnectionUtil.getConnection();
			sql="INSERT INTO product(pr_name,pr_description,pr_price,rating,pr_ct_id,pr_br_id,image_path) VALUES(?,?,?,?,?,?,?);";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, productName);
			preparedStatement.setString(2, productDescription);
			preparedStatement.setFloat(3, productPrice);
			preparedStatement.setFloat(4, rating);
			preparedStatement.setInt(5, categoryId);
			preparedStatement.setInt(6, brandId);
			preparedStatement.setString(7, imagePath);
			int status=preparedStatement.executeUpdate();
			if(status!=0)
				return true;
			return false;
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		finally {
			try {
				if(connection!=null)
					connection.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(resultSet!=null)
					resultSet.close();
			}
			catch (SQLException e) {
				// TODO: handle exception
				e.printStackTrace();
				throw new GrizzlyStoreException(e.getMessage());
				
			}
		}
		return false;
	}
}
