package com.cognizant.grizzlystore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.grizzlystore.model.ProductBrand;
import com.cognizant.grizzlystore.model.ProductCategory;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.util.ConnectionUtil;

public class ProductDao {
	
	private ProductDao() {}
	private static ProductDao productDao;
	public static ProductDao getProductDao() {
		if(productDao==null) {
			productDao = new ProductDao();
		}
		return productDao;
	}
	
	public List<ProductDetails> getProductDetails(){
		List<ProductDetails> list=new ArrayList<ProductDetails>();
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="";
		try {
			connection=ConnectionUtil.getConnection();
			/*if(sortBy.equals("1"))
				sql="SELECT p.*,b.*,c.* FROM product p JOIN product_brand b JOIN product_category c ON p.pr_br_id=b.br_id AND p.pr_ct_id=c.ct_id order by p.pr_name asc;";
			else if(sortBy.equals("2"))
				sql="SELECT p.*,b.*,c.* FROM product p JOIN product_brand b JOIN product_category c ON p.pr_br_id=b.br_id AND p.pr_ct_id=c.ct_id order by p.pr_price asc;";
			else if(sortBy.equals("1"))
				sql="SELECT p.*,b.*,c.* FROM product p JOIN product_brand b JOIN product_category c ON p.pr_br_id=b.br_id AND p.pr_ct_id=c.ct_id order by p.pr_availability asc;";
			else if(sortBy.equals("1"))
				sql="SELECT p.*,b.*,c.* FROM product p JOIN product_brand b JOIN product_category c ON p.pr_br_id=b.br_id AND p.pr_ct_id=c.ct_id order by p.pr_availability asc;";*/
			sql="SELECT p.*,b.*,c.* FROM product p JOIN product_brand b JOIN product_category c ON p.pr_br_id=b.br_id AND p.pr_ct_id=c.ct_id;";
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				int productId=resultSet.getInt("pr_id");
				String productName=resultSet.getString("pr_name");
				String productDescription=resultSet.getString("pr_description");
				float productPrice=resultSet.getInt("pr_price");
				float rating=resultSet.getFloat("rating");
				//int productCategoryId=resultSet.getInt("pr_ct_id");
				//int productBrandId=resultSet.getInt("pr_br_id");
				int productAvailability=resultSet.getInt("pr_availability");
				String imagePath=resultSet.getString("image_path");
				
				int brandId=resultSet.getInt("br_id");
				String brandName=resultSet.getString("br_name");
				
				int categoryId=resultSet.getInt("ct_id");
				String categoryName=resultSet.getString("pr_name");
				
				ProductBrand productBrand=new ProductBrand(brandId,brandName);
				ProductCategory productCategory=new ProductCategory(categoryId, categoryName);
				ProductDetails productDetails=new ProductDetails(productId, productName, productDescription, productPrice, rating, productAvailability, imagePath, productBrand, productCategory);
				
				list.add(productDetails);
			}
			return list;
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		finally {
			try {
				if(connection!=null)
					connection.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(resultSet!=null)
					resultSet.close();
			}
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e.getMessage());
			}
		}
		return null;
		
	}

}
