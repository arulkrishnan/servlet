package com.cognizant.grizzlystore.service;

import java.util.List;

import com.cognizant.grizzlystore.dao.ProductDao;
import com.cognizant.grizzlystore.model.ProductDetails;

public class ProductService implements IProductDao {

	ProductDao productDao=ProductDao.getProductDao();
	@Override
	public List<ProductDetails> getProductDetails() {
		// TODO Auto-generated method stub
		return productDao.getProductDetails();
	}

}
