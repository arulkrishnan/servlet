package com.cognizant.Airport.HibernateService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.Airport.model.PlaneDetails;
import com.cognizant.Airport.service.IAddPlaneDao;

@Service("airportManagementSystemAddPlaneService")
public class AirportManagementSystemAddPlaneService implements IAddPlaneDao {

	@Autowired
	IAddPlaneDao airportMangementDao;
	
	@Override
	public boolean addPlane(PlaneDetails planeDetails) {
		// TODO Auto-generated method stub
		return airportMangementDao.addPlane(planeDetails);
	}

}
