package com.cognizant.Airport.Controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.Airport.model.PlaneDetails;
import com.cognizant.Airport.service.IAddPlaneDao;

@Controller
public class PlaneController {
	
	@Resource(name = "airportManagementSystemAddPlaneService")
	IAddPlaneDao addPlaneDaoservice;
	
	@RequestMapping(value = "/addPlane", method = RequestMethod.GET)
	String addproductPage() {
		return "";	//JSP name of add plane page
	}

	@RequestMapping(value = "/AddPlaneController", method = RequestMethod.POST)
	public ModelAndView addProduct(PlaneDetails planeDetails, ModelAndView modelAndView, String option){
		if (option.equals("")) { //Add Button name
			boolean isPlaneInsertedSuccessfully = addPlaneDaoservice.addPlane(planeDetails);
			if(isPlaneInsertedSuccessfully) {
				modelAndView = new ModelAndView("");	//JSP name of success page
				modelAndView.addObject("", "");	//Attribute name and Message to be displayed on the success page 
			}
		} else if (option.equals("")) {	//Cancel button name
			modelAndView = new ModelAndView("");	//JSP name of success page
			modelAndView.addObject("", "");	//Attribute name and Message to be displayed on the success page 
		}
		return modelAndView;
	}

}
