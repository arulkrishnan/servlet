package com.cognizant.Airport.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

@Entity
@Table(name="plane_details")
public class PlaneDetails {
	@Column(name="plane_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int planeId;
	@Column(name="owner_id")
	private int ownerId;
	@Column(name="owner_first_name")
	private String ownerFirstName;
	@Column(name="owner_last_name")
	private String ownerLastName;
	@Column(name="owenr_contact")
	private int ownerContact;
	@Column(name="owner_email")
	private String ownerEmail;
	@Column(name="plane_type")
	private String planeType;
	@Column(name="plane_capacity")
	private int planeCapacity;
	
	public int getPlaneId() {
		return planeId;
	}
	public void setPlaneId(int planeId) {
		this.planeId = planeId;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerFirstName() {
		return ownerFirstName;
	}
	public void setOwnerFirstName(String ownerFirstName) {
		this.ownerFirstName = ownerFirstName;
	}
	public String getOwnerLastName() {
		return ownerLastName;
	}
	public void setOwnerLastName(String ownerLastName) {
		this.ownerLastName = ownerLastName;
	}
	public int getOwnerContact() {
		return ownerContact;
	}
	public void setOwnerContact(int ownerContact) {
		this.ownerContact = ownerContact;
	}
	public String getOwnerEmail() {
		return ownerEmail;
	}
	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}
	public String getPlaneType() {
		return planeType;
	}
	public void setPlaneType(String planeType) {
		this.planeType = planeType;
	}
	public int getPlaneCapacity() {
		return planeCapacity;
	}
	public void setPlaneCapacity(int planeCapacity) {
		this.planeCapacity = planeCapacity;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ownerContact;
		result = prime * result + ((ownerEmail == null) ? 0 : ownerEmail.hashCode());
		result = prime * result + ((ownerFirstName == null) ? 0 : ownerFirstName.hashCode());
		result = prime * result + ownerId;
		result = prime * result + ((ownerLastName == null) ? 0 : ownerLastName.hashCode());
		result = prime * result + planeCapacity;
		result = prime * result + planeId;
		result = prime * result + ((planeType == null) ? 0 : planeType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlaneDetails other = (PlaneDetails) obj;
		if (ownerContact != other.ownerContact)
			return false;
		if (ownerEmail == null) {
			if (other.ownerEmail != null)
				return false;
		} else if (!ownerEmail.equals(other.ownerEmail))
			return false;
		if (ownerFirstName == null) {
			if (other.ownerFirstName != null)
				return false;
		} else if (!ownerFirstName.equals(other.ownerFirstName))
			return false;
		if (ownerId != other.ownerId)
			return false;
		if (ownerLastName == null) {
			if (other.ownerLastName != null)
				return false;
		} else if (!ownerLastName.equals(other.ownerLastName))
			return false;
		if (planeCapacity != other.planeCapacity)
			return false;
		if (planeId != other.planeId)
			return false;
		if (planeType == null) {
			if (other.planeType != null)
				return false;
		} else if (!planeType.equals(other.planeType))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "PlaneDetails [planeId=" + planeId + ", ownerId=" + ownerId + ", ownerFirstName=" + ownerFirstName
				+ ", ownerLastName=" + ownerLastName + ", ownerContact=" + ownerContact + ", ownerEmail=" + ownerEmail
				+ ", planeType=" + planeType + ", planeCapacity=" + planeCapacity + "]";
	}
	public PlaneDetails(int planeId, int ownerId, String ownerFirstName, String ownerLastName, int ownerContact,
			String ownerEmail, String planeType, int planeCapacity) {
		super();
		this.planeId = planeId;
		this.ownerId = ownerId;
		this.ownerFirstName = ownerFirstName;
		this.ownerLastName = ownerLastName;
		this.ownerContact = ownerContact;
		this.ownerEmail = ownerEmail;
		this.planeType = planeType;
		this.planeCapacity = planeCapacity;
	}
	public PlaneDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
