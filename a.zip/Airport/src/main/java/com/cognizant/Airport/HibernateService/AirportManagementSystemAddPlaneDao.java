package com.cognizant.Airport.HibernateService;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.Airport.model.PlaneDetails;
import com.cognizant.Airport.service.IAddPlaneDao;

@Component
public class AirportManagementSystemAddPlaneDao implements IAddPlaneDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	@Override
	public boolean addPlane(PlaneDetails planeDetails) {
		// TODO Auto-generated method stub
		entityManager.merge(planeDetails);
		return false;
	}
	
}
