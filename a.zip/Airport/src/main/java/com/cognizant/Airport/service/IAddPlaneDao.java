package com.cognizant.Airport.service;

import com.cognizant.Airport.model.PlaneDetails;

public interface IAddPlaneDao {
	public boolean addPlane(PlaneDetails planeDetails);
}
