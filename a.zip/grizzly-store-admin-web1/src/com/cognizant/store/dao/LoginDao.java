package com.cognizant.store.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cognizant.store.exception.IStoreMessages;
import com.cognizant.store.exception.StoreException;
import com.cognizant.store.model.LoginDetails;
import com.cognizant.store.util.ConnectionUtil;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

public class LoginDao {

	public boolean loginDo(LoginDetails logindetails) throws Exception {
		Connection connection=ConnectionUtil.getConnection();
		String sql="";
		ResultSet resultset=null;
		PreparedStatement preparedstatement=null;
		if(connection!=null) {
			try {
				sql="SELECT username,password,status FROM user WHERE username=?;";
				preparedstatement=connection.prepareStatement(sql);
				preparedstatement.setString(1, logindetails.getUsername());
				resultset=preparedstatement.executeQuery();
				if(resultset!=null) {
					resultset.next();
					if(resultset.getString("username").equals(logindetails.getUsername())) {
						if(resultset.getInt("status")<3) {
							if(resultset.getString("password").equals(logindetails.getPassword())) {
								sql="UPDATE user SET status=? WHERE username=?;";
								preparedstatement=connection.prepareStatement(sql);
								preparedstatement.setInt(1, 0);
								preparedstatement.setString(2, logindetails.getUsername());
								preparedstatement.executeUpdate();
								return true;
							}
							else {
								sql="SELECT status FROM user WHERE username=?;";
								preparedstatement=connection.prepareStatement(sql);
								preparedstatement.setString(1, logindetails.getUsername());
								resultset=preparedstatement.executeQuery();
								resultset.next();
								int status=resultset.getInt("status");
								status++;
								sql="UPDATE user SET status=? WHERE username=?;";
								preparedstatement=connection.prepareStatement(sql);
								preparedstatement.setInt(1, status);
								preparedstatement.setString(2, logindetails.getUsername());
								preparedstatement.executeUpdate();
								return false;
							}
						}
						else {
							throw new StoreException(IStoreMessages.ATTEMPTEXCEDDED);
						}
					}
				}
				else {
					
				}
				
			}
			catch (Exception e) {
				// TODO: handle exception
				throw new StoreException(IStoreMessages.SQL);
			}
			finally {

				try {
					if (resultset != null)
						resultset.close();
					
					if (preparedstatement != null)
						preparedstatement.close();
					
					if (connection != null)
						connection.close();
					
				} catch (SQLException e) {
					throw new StoreException(e.getMessage());
				}

			}
		}
		else {
			throw new StoreException(IStoreMessages.DATABASECONNECTIONERROR);
		}
		return false;
	}

}
