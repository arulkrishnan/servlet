package com.cognizant.store.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionUtil {
	public static Connection getConnection() throws Exception {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/databaseStore", "root", "root");
			//System.out.println(con);
			return con;
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Connection not established!!!!!!!!!!!!!!");
		}
		return null;
	}

}
