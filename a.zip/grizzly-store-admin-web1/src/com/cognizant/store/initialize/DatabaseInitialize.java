package com.cognizant.store.initialize;

import java.sql.Statement;
import java.sql.Connection;
import com.cognizant.store.util.ConnectionUtil;

public class DatabaseInitialize {
	public boolean doInitialization() {
		try {
			Connection connection=ConnectionUtil.getConnection();
			if(connection!=null) {
				Statement statement=connection.createStatement();
				String sql="CREATE DATABASE IF NOT EXISTS databaseStore;";
				statement.executeQuery(sql);
				sql="USE databaseStore";
				statement.executeQuery(sql);
				sql="CREATE TABLE IF NOT EXISTS user(username VARCHAR(20) PRIMARY KEY,password VARCHAR(20) NOT NULL,type VARCHAR(10) NOT NULL,name VARCHAR(20) NOT NULL,status INT(11) DEFAULT 0,designationId INT(11) NOT NULL,officeId INT(11) NOT NULL);";
				statement.execute(sql);
				sql="CREATE TABLE IF NOT EXISTS products(productId INT(11) PRIMARY KEY AUTO_INCREMENT,name VARCHAR(20) NOT NULL,brandId INT(11) NOT NULL,categoryId INT(11) NOT NULL,rating FLOAT(1,1) NOT NULL);";
				statement.execute(sql);
				sql="CREATE TABLE office(id INT(11) PRIMARY KEY,name VARCHAR(30) NOT NULL)";
				statement.execute(sql);
				sql="CREATE TABLE designation(id INT(11) PRIMARY KEY,name VARCHAR(30) NOT NULL)";
				statement.execute(sql);
				sql="CREATE TABLE brand(id INT(11) PRIMARY KEY,name VARCHAR(30) NOT NULL)";
				statement.execute(sql);
				sql="CREATE TABLE category(id INT(11) PRIMARY KEY,name VARCHAR(30) NOT NULL)";
				statement.execute(sql);
				connection.close();
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}

}
