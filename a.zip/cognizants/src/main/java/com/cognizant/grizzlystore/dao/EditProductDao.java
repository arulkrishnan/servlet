package com.cognizant.grizzlystore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.grizzlystore.model.ProductBrand;
import com.cognizant.grizzlystore.model.ProductCategory;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.util.ConnectionUtil;

public class EditProductDao {
	
	public boolean blockProduct(String[] productIds){
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="";
		int count=0;
		try {
			connection=ConnectionUtil.getConnection();
			for(int i=0;i<productIds.length;i++) {
				sql="UPDATE product SET pr_availability=0 WHERE pr_id=?;";
				preparedStatement=connection.prepareStatement(sql);
				preparedStatement.setInt(1, Integer.parseInt(productIds[i]));
				int x=preparedStatement.executeUpdate();
				if(x==1)
					count++;
			}
			if(productIds.length==count)
				return true;
			else
				return false;
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		finally {
			try {
				if(connection!=null)
					connection.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(resultSet!=null)
					resultSet.close();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return false;
	}
	public boolean removeProduct(String[] productIds) {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="";
		int count=0;
		try {
			connection=ConnectionUtil.getConnection();
			for(int i=0;i<productIds.length;i++) {
				sql="DELETE FROM product WHERE pr_id=?;";
				preparedStatement=connection.prepareStatement(sql);
				preparedStatement.setInt(1, Integer.parseInt(productIds[i]));
				int x=preparedStatement.executeUpdate();
				if(x==1)
					count++;
			}
			if(productIds.length==count)
				return true;
			else
				return false;
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		finally {
			try {
				if(connection!=null)
					connection.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(resultSet!=null)
					resultSet.close();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return false;
	}
	public List<ProductDetails> viewProduct(String[] productIds) {
		List<ProductDetails> list=new ArrayList<ProductDetails>();
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="";
		try {
			connection=ConnectionUtil.getConnection();
			sql="SELECT p.*,b.*,c.* FROM product p JOIN product_brand b JOIN product_category c ON p.pr_br_id=b.br_id AND p.pr_ct_id=c.ct_id WHERE p.pr_id=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1, Integer.parseInt(productIds[0]));
			resultSet=preparedStatement.executeQuery();
			resultSet.next();
			int productId=resultSet.getInt("pr_id");
			String productName=resultSet.getString("pr_name");
			String productDescription=resultSet.getString("pr_description");
			float productPrice=resultSet.getInt("pr_price");
			float rating=resultSet.getFloat("rating");
			//int productCategoryId=resultSet.getInt("pr_ct_id");
			//int productBrandId=resultSet.getInt("pr_br_id");
			int productAvailability=resultSet.getInt("pr_availability");
			String imagePath=resultSet.getString("image_path");
			
			int brandId=resultSet.getInt("br_id");
			String brandName=resultSet.getString("br_name");
			
			int categoryId=resultSet.getInt("ct_id");
			String categoryName=resultSet.getString("pr_name");
			
			ProductBrand productBrand=new ProductBrand(brandId,brandName);
			ProductCategory productCategory=new ProductCategory(categoryId, categoryName);
			ProductDetails productDetails=new ProductDetails(productId, productName, productDescription, productPrice, rating, productAvailability, imagePath, productBrand, productCategory);
			
			list.add(productDetails);
			return list;
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		finally {
			try {
				if(connection!=null)
					connection.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(resultSet!=null)
					resultSet.close();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

}
