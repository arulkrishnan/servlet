package com.cognizant.grizzlystore.service;

import java.util.List;

import com.cognizant.grizzlystore.dao.EditProductDao;
import com.cognizant.grizzlystore.model.ProductDetails;

public class EditProductService implements IEditProductDao {

	EditProductDao editProductDao=new EditProductDao();
	@Override
	public boolean blockProduct(String[] productIds) {
		// TODO Auto-generated method stub
		return editProductDao.blockProduct(productIds);
	}

	@Override
	public boolean removeProduct(String[] productIds) {
		// TODO Auto-generated method stub
		return editProductDao.removeProduct(productIds);
	}

	@Override
	public List<ProductDetails> viewProduct(String[] productIds) {
		// TODO Auto-generated method stub
		return editProductDao.viewProduct(productIds);
	}

}
