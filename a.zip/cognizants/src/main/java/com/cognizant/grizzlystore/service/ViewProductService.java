package com.cognizant.grizzlystore.service;

import java.util.List;

import com.cognizant.grizzlystore.dao.ViewProductDao;
import com.cognizant.grizzlystore.model.ProductDetails;

public class ViewProductService implements IViewProductDao {

	ViewProductDao viewProductDao=new ViewProductDao();
	@Override
	public List<ProductDetails> getProductDetails(int productId) {
		// TODO Auto-generated method stub
		return viewProductDao.getProductDetails(productId);
	}

}
