package com.cognizant.grizzlystore.service;

public interface IGrizzleStore extends IAddProductDao, IEditProductDao, ILoginDao, IProductDao, IViewProductDao {

}
