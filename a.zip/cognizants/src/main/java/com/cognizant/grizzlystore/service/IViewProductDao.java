package com.cognizant.grizzlystore.service;

import java.util.List;

import com.cognizant.grizzlystore.model.ProductDetails;

public interface IViewProductDao {

	public List<ProductDetails> getProductDetails(int productId);
}
