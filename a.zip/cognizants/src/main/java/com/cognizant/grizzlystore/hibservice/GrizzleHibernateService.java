package com.cognizant.grizzlystore.hibservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.grizzlystore.exception.GrizzlyStoreException;
import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.service.IGrizzleStore;

@Service("ghrizzleHibernateService")
public class GrizzleHibernateService implements IGrizzleStore {

	@Autowired
	IGrizzleStore grizzleHibernateDao;
	
	@Override
	public List<ProductDetails> getProductDetails(int productId) {
		// TODO Auto-generated method stub
		return grizzleHibernateDao.getProductDetails();
	}

	@Override
	public boolean addProduct(ProductDetails productDetails) throws GrizzlyStoreException {
		// TODO Auto-generated method stub
		return grizzleHibernateDao.addProduct(productDetails);
	}

	@Override
	public boolean blockProduct(String[] productIds) {
		// TODO Auto-generated method stub
		return grizzleHibernateDao.blockProduct(productIds);
	}

	@Override
	public boolean removeProduct(String[] productIds) {
		// TODO Auto-generated method stub
		return grizzleHibernateDao.removeProduct(productIds);
	}

	@Override
	public List<ProductDetails> viewProduct(String[] productIds) {
		// TODO Auto-generated method stub
		return grizzleHibernateDao.viewProduct(productIds);
	}

	@Override
	public List<ProductDetails> getProductDetails() {
		// TODO Auto-generated method stub
		return grizzleHibernateDao.getProductDetails();
	}

	@Override
	public int doLogin(LoginDetails loginDetails) throws GrizzlyStoreException, Exception {
		// TODO Auto-generated method stub
		return grizzleHibernateDao.doLogin(loginDetails);
	}

}
