package com.cognizant.grizzlystore.model;

public class Validation {

	public static boolean isUsernameValid(String username,String givenUsername) {
		if(username.equals(givenUsername))
			return true;
		return false;
	}
	public static boolean isPasswordValid(String password,String givenPassord) {
		if(password.equals(givenPassord))
			return true;
		return false;
	}
	public static boolean isStatusValid(int count) {
		if(count<3)
			return true;
		return false;
	}
	public static int checkBrandId(String brandName) {
		if(brandName.equals("Phillips"))
			return 1;
		else if(brandName.equals("Braun"))
			return 2;
		else if(brandName.equals("Apple"))
			return 3;
		else if(brandName.equals("Sakura Pigma"))
			return 4;
		else
			return 5;
	}
	public static int checkCategoryId(String categoryName) {
		if(categoryName.equals("Personal Care"))
			return 1;
		else if(categoryName.equals("Laptops"))
			return 2;
		else
			return 3;
	}
}
