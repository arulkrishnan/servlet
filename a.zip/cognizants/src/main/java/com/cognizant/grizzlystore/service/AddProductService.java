package com.cognizant.grizzlystore.service;

import com.cognizant.grizzlystore.dao.AddProductDao;
import com.cognizant.grizzlystore.exception.GrizzlyStoreException;
import com.cognizant.grizzlystore.model.ProductDetails;

public class AddProductService implements IAddProductDao {

	AddProductDao addProductDao=new AddProductDao();
	@Override
	public boolean addProduct(ProductDetails productDetails) throws GrizzlyStoreException {
		// TODO Auto-generated method stub
		return addProductDao.addProduct(productDetails);
	}

}
