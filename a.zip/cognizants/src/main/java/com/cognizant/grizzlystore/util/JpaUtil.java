package com.cognizant.grizzlystore.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaUtil{

    public JpaUtil() {

          // TODO Auto-generated constructor stub
    }
//  factory=Persistence.createEntityManagerFactory("LOCAL_PERSISTENCE");
    static EntityManager entityManager;
    private static EntityManagerFactory entityManagerFactory;
    public static EntityManagerFactory getEntityManagerFactory()
    {

          if(entityManagerFactory==null)
          {
          entityManagerFactory=Persistence.createEntityManagerFactory("LOCAL_PERSISTENCE");
          }
          
          return entityManagerFactory;
          
    }
    public static EntityManager getEntityManager()
    {

          if(entityManager==null)
          {
               entityManager=JpaUtil.getEntityManagerFactory().createEntityManager();
          }
          
          return entityManager;
          
    }

}
