package com.cognizant.grizzlystore.exception;

public interface IGrizzlyStoreMessages {
	public String DATABASECONNECTIONERROR="Error while establishing a connection";
	public String USERERROR="Username or password is wrong!!";
	public String DRIVER="Driver missing!!!";
	public String SQL="Database error!!!";
	public String ATTEMPTEXCEDDED = "Your maximum attempt is exceed. Please contact Admin for further process!!";

}
