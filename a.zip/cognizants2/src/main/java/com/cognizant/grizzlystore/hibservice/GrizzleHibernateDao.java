package com.cognizant.grizzlystore.hibservice;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.grizzlystore.exception.GrizzlyStoreException;
import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.service.IGrizzleStore;

@Component
public class GrizzleHibernateDao implements IGrizzleStore {

	@PersistenceContext
	private EntityManager entityManager;
	
	@org.springframework.transaction.annotation.Transactional
	@Override
	public boolean blockProduct(String[] productIds) {
		// TODO Auto-generated method stub
		int count=0;
		for(int i=0;i<productIds.length;i++) {
			ProductDetails productDetails = new ProductDetails();
			productDetails.setProductId(Integer.parseInt(productIds[i]));
			productDetails=entityManager.find(ProductDetails.class, Integer.parseInt(productIds[i]));
			productDetails.setProductAvailability(0);
			entityManager.merge(productDetails);
			count++;
		}
		if(count==productIds.length)
			return true;
		else
			return false;
	}

	@org.springframework.transaction.annotation.Transactional
	@Override
	public boolean removeProduct(String[] productIds) {
		// TODO Auto-generated method stub
		for(int i=0;i<productIds.length;i++) {
			ProductDetails productDetails = entityManager.find(ProductDetails.class, Integer.parseInt(productIds[i]));
			entityManager.remove(productDetails);
		}
		return true;
	}

	@Override
	public List<ProductDetails> viewProduct(String[] productIds) {
		// TODO Auto-generated method stub
		TypedQuery<ProductDetails> query=entityManager.createQuery("select p from ProductDetails p where p.productId=?",ProductDetails.class);
		query.setParameter(0,Integer.parseInt(productIds[0]));
		List<ProductDetails> list = query.getResultList();
		return list;
	}

	@Override
	public List<ProductDetails> getProductDetails() {
		// TODO Auto-generated method stub
		TypedQuery<ProductDetails> query=entityManager.createQuery("select p from ProductDetails p",ProductDetails.class);
		List<ProductDetails> list = query.getResultList();
		return list;
	}

	@Transactional
	@Override
	public int doLogin(LoginDetails loginDetails) throws GrizzlyStoreException, Exception {
		// TODO Auto-generated method stub
		List<LoginDetails> list=null;
		Query query=entityManager.createQuery("select l from LoginDetails l where l.username=?");
		query.setParameter(0, loginDetails.getUsername());
		list = query.getResultList();
		if(list.isEmpty()==false) {
			if(list.get(0).getAttempt() < 3)
			{
				if(list.get(0).getPassword().equals(loginDetails.getPassword())) {
					System.out.println("Successfully logged in!!!");
					LoginDetails loginDetails2 = new LoginDetails();
					loginDetails2.setUsername(loginDetails.getUsername());
					loginDetails2 = entityManager.find(LoginDetails.class, loginDetails.getUsername());
					loginDetails2.setAttempt(0);
					entityManager.merge(loginDetails2);
					return 1;
				}
				else {
					System.err.println("Username or password is wrong!!!");
					LoginDetails loginDetails2 = new LoginDetails();
					loginDetails2.setUsername(loginDetails.getUsername());
					loginDetails2 = entityManager.find(LoginDetails.class, loginDetails.getUsername());
					loginDetails2.setAttempt(loginDetails2.getAttempt()+1);
					entityManager.merge(loginDetails2);
					return 0;
					//throw new GrizzlyStoreException(IGrizzlyStoreMessages.USERERROR);
				}
			}
			else {
				System.err.println("Maximum attempt excedded, Please contact admin!!!");
				return -1;
				//throw new GrizzlyStoreException(IGrizzlyStoreMessages.USERERROR);
			}
		}
		else {
			System.err.println("User not available!!");
		}
		return 0;
	}

	@org.springframework.transaction.annotation.Transactional
	@Override
	public boolean addProduct(ProductDetails productDetails) throws GrizzlyStoreException {
		// TODO Auto-generated method stub
		entityManager.merge(productDetails);
		return true;
	}

	@Override
	public List<ProductDetails> getProductDetails(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

}
