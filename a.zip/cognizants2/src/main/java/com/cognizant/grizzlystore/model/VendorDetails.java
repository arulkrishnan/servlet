package com.cognizant.grizzlystore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vendor")
public class VendorDetails {
	
	@Id
	@Column(name="vendor_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int vendorId;
	@Column(name="vendor_name")
	private String vendorName;
	@Column(name="vendor_contact")
	private int vendorContat;
	@Column(name="address")
	private String vendorAddress;
	public int getVendorId() {
		return vendorId;
	}
	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public int getVendorContat() {
		return vendorContat;
	}
	public void setVendorContat(int vendorContat) {
		this.vendorContat = vendorContat;
	}
	public String getVendorAddress() {
		return vendorAddress;
	}
	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((vendorAddress == null) ? 0 : vendorAddress.hashCode());
		result = prime * result + vendorContat;
		result = prime * result + vendorId;
		result = prime * result + ((vendorName == null) ? 0 : vendorName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VendorDetails other = (VendorDetails) obj;
		if (vendorAddress == null) {
			if (other.vendorAddress != null)
				return false;
		} else if (!vendorAddress.equals(other.vendorAddress))
			return false;
		if (vendorContat != other.vendorContat)
			return false;
		if (vendorId != other.vendorId)
			return false;
		if (vendorName == null) {
			if (other.vendorName != null)
				return false;
		} else if (!vendorName.equals(other.vendorName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "VendorDetails [vendorId=" + vendorId + ", vendorName=" + vendorName + ", vendorContat=" + vendorContat
				+ ", vendorAddress=" + vendorAddress + "]";
	}
	public VendorDetails(int vendorId, String vendorName, int vendorContat, String vendorAddress) {
		super();
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.vendorContat = vendorContat;
		this.vendorAddress = vendorAddress;
	}
	public VendorDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
