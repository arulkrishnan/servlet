package com.cognizant.grizzlystore.hibservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.grizzlystore.exception.GrizzlyStoreException;
import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.model.ProductVendorDetails;
import com.cognizant.grizzlystore.service.IGrizzleStoreVendor;

@Service("ghrizzleHibernateServiceVendor")
public class GrizzleHibernateServiceVendor implements IGrizzleStoreVendor {

	@Autowired
	IGrizzleStoreVendor grizzleHibernateDaoVendor;

	@Override
	public int doLogin(LoginDetails loginDetails) throws GrizzlyStoreException, Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ProductVendorDetails> getProductDetails() {
		// TODO Auto-generated method stub
		return grizzleHibernateDaoVendor.getProductDetails();
	}

	@Override
	public boolean addProduct(ProductDetails productDetails) throws GrizzlyStoreException {
		// TODO Auto-generated method stub
		return grizzleHibernateDaoVendor.addProduct(productDetails);
	}

	@Override
	public List<ProductVendorDetails> viewProduct(String productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean manageProduct(String productId) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}
