package com.cognizant.grizzlystore.service;

public interface IEditProductDaoVendor {

	public boolean manageProduct(String productId);
}
