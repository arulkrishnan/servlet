package com.cognizant.grizzlystore.service;

import java.util.List;

import com.cognizant.grizzlystore.model.ProductDetails;

public interface IEditProductDao {
	
	public boolean removeProduct(String[] productIds);
	public List<ProductDetails> viewProduct(String[] productIds);
	boolean blockProduct(String[] productIds);

}
