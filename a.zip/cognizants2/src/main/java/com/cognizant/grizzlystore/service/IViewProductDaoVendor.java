package com.cognizant.grizzlystore.service;

import java.util.List;

import com.cognizant.grizzlystore.model.ProductVendorDetails;

public interface IViewProductDaoVendor {

	public List<ProductVendorDetails> viewProduct(String productId);

	public List<ProductVendorDetails> getProductDetails();
}
