package com.cognizant.grizzlystore.service;

public interface IGrizzleStoreVendor extends ILoginDao, IViewProductDaoVendor, IAddProductDaoVendor, IEditProductDaoVendor {

}
