package com.cognizant.grizzlystore.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="product_vendor_details")
public class ProductVendorDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="vendor_id")
	private VendorDetails vendorDetails;
	@Id
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="product_id")
	private ProductDetails productDetails;
	@Column(name="in_stock")
	private int inStock;
	public ProductDetails getProductDetails() {
		return productDetails;
	}
	public void setProductDetails(ProductDetails productDetails) {
		this.productDetails = productDetails;
	}
	public VendorDetails getVendorDetails() {
		return vendorDetails;
	}
	public void setVendorDetails(VendorDetails vendorDetails) {
		this.vendorDetails = vendorDetails;
	}
	public int getInStock() {
		return inStock;
	}
	public void setInStock(int inStock) {
		this.inStock = inStock;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + inStock;
		result = prime * result + ((productDetails == null) ? 0 : productDetails.hashCode());
		result = prime * result + ((vendorDetails == null) ? 0 : vendorDetails.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductVendorDetails other = (ProductVendorDetails) obj;
		if (inStock != other.inStock)
			return false;
		if (productDetails == null) {
			if (other.productDetails != null)
				return false;
		} else if (!productDetails.equals(other.productDetails))
			return false;
		if (vendorDetails == null) {
			if (other.vendorDetails != null)
				return false;
		} else if (!vendorDetails.equals(other.vendorDetails))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ProductVendorDetails [productDetails=" + productDetails + ", vendorDetails=" + vendorDetails
				+ ", inStock=" + inStock + "]";
	}
	public ProductVendorDetails(ProductDetails productDetails, VendorDetails vendorDetails, int inStock) {
		super();
		this.productDetails = productDetails;
		this.vendorDetails = vendorDetails;
		this.inStock = inStock;
	}
	public ProductVendorDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
