package com.cognizant.grizzlystore.hibservice;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;

import com.cognizant.grizzlystore.exception.GrizzlyStoreException;
import com.cognizant.grizzlystore.model.LoginDetails;
import com.cognizant.grizzlystore.model.ProductDetails;
import com.cognizant.grizzlystore.model.ProductVendorDetails;
import com.cognizant.grizzlystore.service.IGrizzleStoreVendor;

@Component
public class GrizzleHibernateDaoVendor implements IGrizzleStoreVendor {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int doLogin(LoginDetails loginDetails) throws GrizzlyStoreException, Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean addProduct(ProductDetails productDetails) throws GrizzlyStoreException {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public List<ProductVendorDetails> viewProduct(String productId) {
		// TODO Auto-generated method stub
		TypedQuery<ProductVendorDetails> query=entityManager.createQuery("select p from ProductDetails p where p.productId=?",ProductVendorDetails.class);
		query.setParameter(0,Integer.parseInt(productId));
		List<ProductVendorDetails> list = query.getResultList();
		return list;
	}

	@Override
	public List<ProductVendorDetails> getProductDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean manageProduct(String productId) {
		// TODO Auto-generated method stub
		return false;
	}

}
